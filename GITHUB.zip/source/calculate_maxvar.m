function [p,maxvar] = calculate_maxvar(A)
%Calculates the maximum variance distribution (p) and corresponding maximum
%variance (maxvar) for a connected graph with adjacency matrix A
%This implementation requires installation of CVX, see http://cvxr.com/cvx/

%preprocessing (pQ = pseudoinverse Laplacian)
n=length(A);
Q=diag(sum(A))-A;
pQ=pinv(Q); 

%parameters for the optimization problem
zeta=diag(pQ);
zerovec=zeros(n,1);
u=ones(n,1);

%Solve the maximum variance problem
cvx_begin quiet
    variable p(n)
    maximize( -quad_form(p,pQ)+zeta'*p )
    subject to
    p>=zerovec;
    u'*p==1;
cvx_end;

%return the optimal solution (maxvar = variance, p = distribution)
maxvar=cvx_optval;
p;
end
