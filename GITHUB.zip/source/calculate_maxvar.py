def calculate_maximum_variance(A):
    #Calculates  the  maximum  variance  distribution (p) and  corresponding maximum  variance (maxvar) 
    #for a connected  graph  with  adjacency matrix A (in np.matrix  of  array  form)
    
    #preprocessing (pQ = pseudoinverse Laplacian)
    A = np.array(A)
    n = len(A)
    Q = np.diag(np.sum(A,axis=1))-A
    pQ = np.linalg.pinv(Q)
    
    #parameters for the optimization problem
    zeta = np.diag(pQ)
    u = np.ones(n)
    zerovec = np.zeros(n)
    
    #solve the maximum variance problem    
    x = cp.Variable(n)
    prob = cp.Problem(cp.Maximize(-cp.quad_form(x, pQ) + zeta.T @ x),
                 [x >= zerovec,
                  u @ x == 1])
    prob.solve()
    
    #return the optimal solution (maxvar = variance, p = distribution)
    maxvar = prob.value
    p = x.value
    
    return p,maxvar