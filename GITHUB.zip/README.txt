# variance
Accompanying codes, figures and data for the paper "Variance and covariance of distributions on graphs", Karel Devriendt, Samuel Martin-Gutierrez, Renaud Lambiotte, https://arxiv.org/abs/2008.09155

Do not hesitate to send us an email (renaud.lambiotte@maths.ox.ac.uk) if you have any question or recommendations.